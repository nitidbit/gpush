class GpushError < StandardError; end
